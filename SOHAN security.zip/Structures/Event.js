const { Client } = require('discord.js'),
  fs = require('fs'),
  path = require('path')
module.exports = async (_0x1fd04c) => {
  let _0x1af921 = path.join(__dirname, '..', 'Events')
  fs.readdir(_0x1af921, (_0x3caabe, _0x1705fd) => {
    if (_0x3caabe) {
      console.log(_0x3caabe)
    } else {
      _0x1705fd.forEach((_0x4c6682) => {
        const _0x3a00cc = require(_0x1af921 + '/' + _0x4c6682)
        _0x1fd04c.on(_0x4c6682.split('.')[0], _0x3a00cc.bind(null, _0x1fd04c))
        console.log('Event Loaded: ' + _0x4c6682.split('.')[0])
      })
    }
  })
}