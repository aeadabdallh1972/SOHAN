const { Collection, MessageEmbed, Client, Intents } = require('discord.js')
class Erica extends Client {
  constructor(_0x30b6fd) {
    super(_0x30b6fd)
    this.commands = new Collection()
    this.slashCommands = new Collection()
    this.config = require('../config')
  }
  ['start'](_0x8c1da5) {
    if (!_0x8c1da5) {
      return console.error('You forgot to provide the token of the bot.')
    }
    this.login(_0x8c1da5)
  }
}
module.exports = Erica
