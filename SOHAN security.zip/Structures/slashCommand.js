const { Client } = require('discord.js'),
  fs = require('fs')
module.exports = async (_0x3431b4) => {
  const _0x5b72ca = []
  fs.readdirSync('./SlashCommands/').forEach((_0x470901) => {
    const _0x2f67d0 = fs
      .readdirSync('./SlashCommands/' + _0x470901 + '/')
      .filter((_0x426617) => _0x426617.endsWith('.js'))
    for (const _0x1ffb9e of _0x2f67d0) {
      const _0x200567 = require('../SlashCommands/' +
        _0x470901 +
        '/' +
        _0x1ffb9e)
      if (!_0x200567.name) {
        return console.error(
          'SlashCommandNameError: ' +
            _0x200567.split('.')[0] +
            ' application command name is required.'
        )
      }
      if (!_0x200567.description) {
        return console.error(
          'SlashCommandDescriptionError: ' +
            _0x200567.split('.')[0] +
            ' application command description is required.'
        )
      }
      _0x3431b4.slashCommands.set(_0x200567.name, _0x200567)
      console.log('Client SlashCommands Command (/) Loaded: ' + _0x200567.name)
      _0x5b72ca.push(_0x200567)
    }
  })
  _0x3431b4.on('ready', async () => {
    await _0x3431b4.application.commands
      ?.set(_0x5b72ca)
      .then(() => console.log('Client SlashCommand (/) Registered.'))
      .catch((_0x2810e7) => console.log(_0x2810e7))
  })
}
