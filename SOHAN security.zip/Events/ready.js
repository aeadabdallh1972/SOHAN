const Discord = require('discord.js'),
  config = require('../config.js'),
  colors = require('colors')
module.exports = async (_0x1bcac4) => {
  _0x1bcac4.user.setPresence({
    status: 'online',
    activities: [
      {
        name: _0x1bcac4.config.status,
        type: 'WATCHING',
      },
    ],
  })
  console.log('[API] Logged in as ' + _0x1bcac4.user.tag + '.')
  console.log('Made by: Bandar'.inverse)
}
