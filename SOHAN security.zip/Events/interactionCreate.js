const { MessageEmbed } = require('discord.js')
module.exports = async (_0x145393, _0x3c6a8d) => {
  if (!_0x3c6a8d.guild) {
    return
  }
  if (_0x3c6a8d.isCommand()) {
    const _0x2b1568 = _0x145393.slashCommands.get(_0x3c6a8d.commandName)
    if (!_0x2b1568) {
      return
    }
    try {
      _0x2b1568.run(_0x145393, _0x3c6a8d)
    } catch (_0x41fce3) {
      _0x3c6a8d.replied
        ? await _0x3c6a8d
            .editReply({ content: 'An unexcepted error occured.' })
            .catch(() => {})
        : await _0x3c6a8d
            .followUp({
              ephemeral: true,
              content: 'An unexcepted error occured.',
            })
            .catch(() => {})
      console.error(_0x41fce3)
    }
  } else {
    return
  }
}
