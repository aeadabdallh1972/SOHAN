module.exports = {
    token: 'MTE4Nzg0ODg0MjUzMjYzNDYzNA.Gq_wtF.QJX2lRharKF0g-K6pN3bgvRcbjI40ts2DRTnu4',//توكن البوت
    status: 'SOHAN security',//حالة البوت
    owners: ['505338936290443264'],//ايديات الي يمديهم يتحكمون بالحماية
    //مطورين البوت عبود | سوهان لتخريب البوتات 😁
    
///////// ايدي هوسهان 571657740322340865
}
