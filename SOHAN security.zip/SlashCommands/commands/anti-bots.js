const { Client, Commandmessage } = require('discord.js'),
  { MessageEmbed } = require('discord.js'),
  db = require('croxydb'),
  ms = require('ms'),
  config = require('../../config.js')
let owners = config.owners,
  choicess = config.choices
module.exports = {
  name: 'anti-bots',
  description: 'تفعيل او تعطيل الحماية من البوتات',
  options: [
    {
      name: 'enableordisable',
      description: 'تفعيل او تعطيل الحماية من البوتات',
      type: 'STRING',
      required: true,
      choices: [
        {
          name: 'تفعيل الحماية من دخول البوتات',
          value: 'enable',
        },
        {
          name: 'تعطيل الحماية من البوتات',
          value: 'disable',
        },
        {
          name: 'تفعيل الحماية من دخول البوتات ولكن السماح للبوتات الموثقة فقط',
          value: 'enable-verified',
        },
      ],
    },
  ],
  run: async (_0x5f13d3, _0x10eb06, _0x132fd4) => {
    if (!owners.includes(_0x10eb06.user.id)) {
      return _0x10eb06.reply('لا تملك الصلاحيات الكافية')
    }
    let _0x79fac4 = _0x10eb06.options.getString('enableordisable')
    if (_0x79fac4 === 'enable') {
      db.set('antibots_' + _0x10eb06.guild.id, 'enable')
      _0x10eb06.reply('تم تفعيل الحماية من دخول البوتات')
    } else {
      if (_0x79fac4 === 'disable') {
        db.set('antibots_' + _0x10eb06.guild.id, 'disable')
        _0x10eb06.reply('تم تعطيل الحماية من البوتات')
      } else {
        _0x79fac4 === 'enable-verified' &&
          (db.set('antibots_' + _0x10eb06.guild.id, 'enable-verified'),
          _0x10eb06.reply(
            'تم تفعيل الحماية من دخول البوتات ولكن السماح للبوتات الموثقة فقط'
          ))
      }
    }
    _0x10eb06.reply('تم تحديد الحد الاقصى للحماية بنجاح')
  },
}
