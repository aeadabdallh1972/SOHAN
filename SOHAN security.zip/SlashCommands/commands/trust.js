const { Client, Commandmessage } = require('discord.js'),
  { MessageEmbed } = require('discord.js'),
  db = require('croxydb'),
  ms = require('ms'),
  config = require('../../config.js')
let owners = config.owners,
  choicess = config.choices
module.exports = {
  name: 'trust',
  description: 'اضافة او ازالة شخص من قائمة الموثوقين',
  options: [
    {
      name: 'user',
      description: 'الشخص',
      type: 'USER',
      required: true,
    },
  ],
  run: async (_0x463cb1, _0x4d5ccb, _0x5117bd) => {
    if (!owners.includes(_0x4d5ccb.user.id)) {
      return _0x4d5ccb.reply('لا تملك الصلاحيات الكافية')
    }
    let _0x18d861 = _0x4d5ccb.options.getUser('user'),
      _0x4377bf = db.get('trusted_' + _0x4d5ccb.guild.id)
    if (
      _0x4377bf &&
      _0x4377bf.find((_0x2a7479) => _0x2a7479.user == _0x18d861.id)
    ) {
      let _0x20cf78 = _0x4377bf.filter(
        (_0x41c4ca) => _0x41c4ca.user !== _0x18d861.id
      )
      db.set('trusted_' + _0x4d5ccb.guild.id, _0x20cf78)
      _0x4d5ccb.reply('تم ازالة ' + _0x18d861 + ' من قائمة الموثوقين')
    } else {
      db.push('trusted_' + _0x4d5ccb.guild.id, { user: _0x18d861.id })
      _0x4d5ccb.reply('تم اضافة ' + _0x18d861 + ' الى قائمة الموثوقين')
    }
  },
}
