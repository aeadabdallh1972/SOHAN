const { Client, Commandmessage } = require('discord.js'),
  { MessageEmbed } = require('discord.js'),
  db = require('croxydb'),
  ms = require('ms'),
  config = require('../../config.js')
let owners = config.owners,
  choicess = config.choices
module.exports = {
  name: 'set-limit',
  description: 'تحديد الحد الاقصى للحماية',
  options: [
    {
      name: 'limit',
      description: 'حد الحماية',
      type: 'NUMBER',
      required: true,
    },
    {
      name: 'type',
      description: 'نوع الحماية',
      type: 'STRING',
      required: true,
      choices: [
        {
          name: 'تفعيل جميع الحمايات',
          value: 'all',
        },
        {
          name: 'الحماية من الباند',
          value: 'ban',
        },
        {
          name: 'الحماية من الطرد',
          value: 'kick',
        },
        {
          name: 'الحماية من انشاء الرتب',
          value: 'crole',
        },
        {
          name: 'الحماية من حذف الرتب',
          value: 'drole',
        },
        {
          name: 'الحماية من اضافة الرتب',
          value: 'arole',
        },
        {
          name: 'الحماية من ازالة الرتب',
          value: 'rrole',
        },
        {
          name: 'الحماية من انشاء الرومات',
          value: 'cchannel',
        },
        {
          name: 'الحماية من حذف الرومات',
          value: 'dchannel',
        },
        {
          name: 'الحماية من تغير الاسماء تشمل : اسم السيرفر , اسماء الرومات , اسماء الرتب',
          value: 'rename',
        },
        {
          name: 'الحماية من دخول البوتات',
          value: 'anti-bots',
        },
      ],
    },
  ],
  run: async (_0x3371e8, _0x24f367, _0x7e28ff) => {
    if (!owners.includes(_0x24f367.user.id)) {
      return _0x24f367.reply('لا تملك الصلاحيات الكافية')
    }
    let _0x49b2ca = _0x24f367.options.getNumber('limit'),
      _0x50e79f = _0x24f367.options.getString('type')
    if (_0x50e79f === 'all') {
      db.set('limit_' + _0x24f367.guild.id, {
        ban: _0x49b2ca,
        kick: _0x49b2ca,
        crole: _0x49b2ca,
        drole: _0x49b2ca,
        cchannel: _0x49b2ca,
        dchannel: _0x49b2ca,
        rename: _0x49b2ca,
        arole: _0x49b2ca,
        rrole: _0x49b2ca,
        antibots: _0x49b2ca,
      })
    } else {
      if (_0x50e79f === 'ban') {
        db.set('limit_' + _0x24f367.guild.id + '.ban', _0x49b2ca)
      } else {
        if (_0x50e79f === 'kick') {
          db.set('limit_' + _0x24f367.guild.id + '.kick', _0x49b2ca)
        } else {
          if (_0x50e79f === 'crole') {
            db.set('limit_' + _0x24f367.guild.id + '.crole', _0x49b2ca)
          } else {
            if (_0x50e79f === 'drole') {
              db.set('limit_' + _0x24f367.guild.id + '.drole', _0x49b2ca)
            } else {
              if (_0x50e79f === 'cchannel') {
                db.set('limit_' + _0x24f367.guild.id + '.cchannel', _0x49b2ca)
              } else {
                if (_0x50e79f === 'dchannel') {
                  db.set('limit_' + _0x24f367.guild.id + '.dchannel', _0x49b2ca)
                } else {
                  if (_0x50e79f === 'rename') {
                    db.set('limit_' + _0x24f367.guild.id + '.rename', _0x49b2ca)
                  } else {
                    if (_0x50e79f === 'arole') {
                      db.set(
                        'limit_' + _0x24f367.guild.id + '.arole',
                        _0x49b2ca
                      )
                    } else {
                      if (_0x50e79f === 'rrole') {
                        db.set(
                          'limit_' + _0x24f367.guild.id + '.rrole',
                          _0x49b2ca
                        )
                      } else {
                        _0x50e79f === 'anti-bots' &&
                          db.set(
                            'limit_' + _0x24f367.guild.id + '.antibots',
                            _0x49b2ca
                          )
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    _0x24f367.reply('تم تحديد الحد الاقصى للحماية بنجاح')
  },
}
