const { Client, Commandmessage } = require('discord.js'),
  { MessageEmbed } = require('discord.js'),
  db = require('croxydb'),
  ms = require('ms'),
  config = require('../../config.js')
let owners = config.owners,
  choicess = config.choices
module.exports = {
  name: 'set-log',
  description: 'تحديد روم اللوق',
  options: [
    {
      name: 'channel',
      description: 'روم اللوق',
      type: 'CHANNEL',
      required: true,
    },
  ],
  run: async (_0x5abf9c, _0xe55e73, _0x3c2749) => {
    if (!owners.includes(_0xe55e73.user.id)) {
      return _0xe55e73.reply('لا تملك الصلاحيات الكافية')
    }
    let _0x14e842 = _0xe55e73.options.getChannel('channel')
    db.set('log_' + _0xe55e73.guild.id, _0x14e842.id)
    _0xe55e73.reply('تم تحديد روم اللوق الى ' + _0x14e842)
  },
}
