const { Client, Commandmessage } = require('discord.js'),
  { MessageEmbed } = require('discord.js'),
  db = require('croxydb'),
  ms = require('ms'),
  config = require('../../config.js')
let owners = config.owners,
  choicess = config.choices
module.exports = {
  name: 'ping',
  description: 'لعرض سرعة استجابة البوت',
  run: async (_0x58f53d, _0x388ba6, _0x4f1e01) => {
    await _0x388ba6.deferReply({ ephemeral: false }).catch(() => {})
    let _0x244d52 = new MessageEmbed()
    _0x244d52.setAuthor(
      _0x388ba6.user.username,
      _0x388ba6.user.avatarURL({ dynamic: true }),
      'https://discord.gg/ber'
    )
    if (_0x388ba6.guild.iconURL({ dynamic: true })) {
      _0x244d52.setThumbnail(_0x388ba6.guild.iconURL({ dynamic: true }))
    }
    _0x244d52.addFields(
      {
        name: 'Ping',
        value: '**' + _0x58f53d.ws.ping + 'ms**',
        inline: true,
      },
      {
        name: 'Uptime',
        value: '**' + ms(_0x58f53d.uptime, { long: true }) + '**',
        inline: true,
      }
    )
    _0x244d52.setFooter('Requested by ' + _0x388ba6.user.username)
    _0x244d52.setTimestamp()
    _0x388ba6.followUp({ embeds: [_0x244d52] })
  },
}
