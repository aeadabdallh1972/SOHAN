const { Client, Commandmessage } = require('discord.js'),
  { MessageEmbed } = require('discord.js'),
  db = require('croxydb'),
  ms = require('ms'),
  config = require('../../config.js')
let owners = config.owners,
  choicess = config.choices
module.exports = {
  name: 'disable-limit',
  description: 'تعطيل الحد الاقصى للحماية',
  options: [
    {
      name: 'type',
      description: 'نوع الحماية',
      type: 'STRING',
      required: true,
      choices: [
        {
          name: 'تعطيل جميع الحمايات',
          value: 'all',
        },
        {
          name: 'تعطيل الحماية من الباند',
          value: 'ban',
        },
        {
          name: 'تعطيل الحماية من الطرد',
          value: 'kick',
        },
        {
          name: 'تعطيل الحماية من انشاء الرتب',
          value: 'crole',
        },
        {
          name: 'تعطيل الحماية من حذف الرتب',
          value: 'drole',
        },
        {
          name: 'تعطيل الحماية من اضافة الرتب',
          value: 'arole',
        },
        {
          name: 'تعطيل الحماية من ازالة الرتب',
          value: 'rrole',
        },
        {
          name: 'تعطيل الحماية من انشاء الرومات',
          value: 'cchannel',
        },
        {
          name: 'تعطيل الحماية من حذف الرومات',
          value: 'dchannel',
        },
        {
          name: 'تعطيل الحماية من تغير الاسماء تشمل : اسم السيرفر , اسماء الرومات , اسماء الرتب',
          value: 'rename',
        },
        {
          name: 'تعطيل الحد من دخول البوتات',
          value: 'anti-bots',
        },
      ],
    },
  ],
  run: async (_0x31bd15, _0x2731f6, _0x3d651e) => {
    if (!owners.includes(_0x2731f6.user.id)) {
      return _0x2731f6.reply('لا تملك الصلاحيات الكافية')
    }
    let _0x3331c4 = _0x2731f6.options.getString('type')
    if (_0x3331c4 === 'all') {
      db.delete('limit_' + _0x2731f6.guild.id)
    } else {
      if (_0x3331c4 === 'ban') {
        db.delete('limit_' + _0x2731f6.guild.id + '.ban')
      } else {
        if (_0x3331c4 === 'kick') {
          db.delete('limit_' + _0x2731f6.guild.id + '.kick')
        } else {
          if (_0x3331c4 === 'crole') {
            db.delete('limit_' + _0x2731f6.guild.id + '.crole')
          } else {
            if (_0x3331c4 === 'drole') {
              db.delete('limit_' + _0x2731f6.guild.id + '.drole')
            } else {
              if (_0x3331c4 === 'cchannel') {
                db.delete('limit_' + _0x2731f6.guild.id + '.cchannel')
              } else {
                if (_0x3331c4 === 'dchannel') {
                  db.delete('limit_' + _0x2731f6.guild.id + '.dchannel')
                } else {
                  if (_0x3331c4 === 'rename') {
                    db.delete('limit_' + _0x2731f6.guild.id + '.rename')
                  } else {
                    if (_0x3331c4 === 'arole') {
                      db.delete('limit_' + _0x2731f6.guild.id + '.arole')
                    } else {
                      if (_0x3331c4 === 'rrole') {
                        db.delete('limit_' + _0x2731f6.guild.id + '.rrole')
                      } else {
                        _0x3331c4 === 'anti-bots' &&
                          db.delete('antibots_' + _0x2731f6.guild.id)
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    _0x2731f6.reply('تم تعطيل الحد الاقصى للحماية')
  },
}
