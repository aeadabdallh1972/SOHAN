const { Client, Commandmessage } = require('discord.js'),
  { MessageEmbed } = require('discord.js'),
  db = require('croxydb'),
  ms = require('ms'),
  config = require('../../config.js')
let owners = config.owners,
  choicess = config.choices
module.exports = {
  name: 'set-punishment',
  description: 'تحديد العقاب',
  options: [
    {
      name: 'type',
      description: 'نوع العقاب',
      type: 'STRING',
      required: true,
      choices: [
        {
          name: 'ازالة جميع رتب العضو',
          value: 'remove-all-roles',
        },
        {
          name: 'طرد العضو',
          value: 'kick',
        },
        {
          name: 'حظر العضو',
          value: 'ban',
        },
      ],
    },
  ],
  run: async (_0x27c127, _0x570a11, _0x490fcc) => {
    if (!owners.includes(_0x570a11.user.id)) {
      return _0x570a11.reply('لا تملك الصلاحيات الكافية')
    }
    let _0x4a2625 = _0x570a11.options.getString('type')
    if (_0x4a2625 === 'remove-all-roles') {
      db.set('punishment_' + _0x570a11.guild.id, 'rroles')
      _0x570a11.reply('تم تحديد العقاب على ازالة جميع رتب العضو')
    } else {
      if (_0x4a2625 === 'kick') {
        db.set('punishment_' + _0x570a11.guild.id, 'kick')
        _0x570a11.reply('تم تحديد العقاب على طرد العضو')
      } else {
        _0x4a2625 === 'ban' &&
          (db.set('punishment_' + _0x570a11.guild.id, 'ban'),
          _0x570a11.reply('تم تحديد العقاب على حظر العضو'))
      }
    }
  },
}
