const { Client, Commandmessage } = require('discord.js'),
  { MessageEmbed } = require('discord.js'),
  db = require('croxydb'),
  ms = require('ms'),
  config = require('../../config.js')
let owners = config.owners,
  choicess = config.choices
module.exports = {
  name: 'help',
  description: 'لعرض قائمة المساعدة',
  run: async (_0x1994db, _0x16a3e2, _0x58e2ec) => {
    await _0x16a3e2.deferReply({ ephemeral: false }).catch(() => {})
    let _0x296181 = new MessageEmbed()
    _0x296181.setAuthor(
      _0x16a3e2.user.username,
      _0x16a3e2.user.avatarURL({ dynamic: true }),
      'https://discord.gg/ber'
    )
    if (_0x16a3e2.guild.iconURL({ dynamic: true })) {
      _0x296181.setThumbnail(_0x16a3e2.guild.iconURL({ dynamic: true }))
    }
    _0x296181.setDescription(
      '**الأوامر العامة**\n`/help` - لعرض قائمة المساعدة\n`/ping` - لعرض بينق البوت\n**اوامر الحماية**\n`/set-limit` - لتحديد الحد الأقصى للحماية\n`/set-log` - لتحديد روم اللوق\n`/set-punishment` - لتحديد العقوبة\n`/trust` - لاضافة او ازالة شخص من قائمة الموثوق بهم\n`/disable-limit` - لتعطيل الحد الأقصى للحماية\n`/antibots` - لتفعيل حماية البوتات\n'
    )
    _0x296181.setFooter('Requested by ' + _0x16a3e2.user.username)
    _0x296181.setTimestamp()
    _0x16a3e2.followUp({ embeds: [_0x296181] })
  },
}
