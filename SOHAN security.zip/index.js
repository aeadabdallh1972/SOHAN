const {
    Intents,
    MessageActionRow,
    MessageButton,
    MessageEmbed,
    Modal,
    TextInputComponent,
  } = require('discord.js'),
  Client = require('./Structures/Client.js'),
  Discord = require('discord.js'),
  Config = require('./config.js'),
  config = require('./config.js'),
  ms = require('ms'),
  db = require('croxydb'),
  client = new Client({
    shards: 'auto',
    allowedMentions: {
      parse: ['users', 'roles', 'everyone'],
      repliedUser: false,
    },
    partials: ['MESSAGE', 'CHANNEL', 'REACTION'],
    intents: 32767,
  }),
  wait = (_0x1ef114) =>
    new Promise((_0x3bf6cf) => setTimeout(_0x3bf6cf, _0x1ef114))
client.on('guildBanAdd', async (_0x46d551, _0x3283e9) => {
  let _0x4ccd43 = await _0x46d551.guild.fetchAuditLogs({
      limit: 1,
      type: 'MEMBER_BAN_ADD',
    }),
    _0x19e7a2 = _0x4ccd43.entries.first(),
    _0x561f93 = db.get('limit_' + _0x46d551.guild.id + '.ban'),
    _0x59e850 = db.get(
      'userlimit_' + _0x46d551.guild.id + '_' + _0x19e7a2.executor.id + '.ban'
    )
  !_0x59e850 &&
    (db.set(
      'userlimit_' + _0x46d551.guild.id + '_' + _0x19e7a2.executor.id + '.ban',
      1
    ),
    (_0x59e850 = 1))
  let _0x3e58dc = db.get('punishment_' + _0x46d551.guild.id),
    _0x3ae39f = db.get('log_' + _0x46d551.guild.id),
    _0x4f1152 = db.get('trusted_' + _0x46d551.guild.id)
  if (!_0x561f93 || !_0x3e58dc) {
    return
  }
  if (
    _0x4f1152 &&
    _0x4f1152.find((_0x4db9bc) => _0x4db9bc.user == _0x19e7a2.executor.id)
  ) {
    return
  }
  if (_0x19e7a2.executor.id == client.user.id) {
    return
  }
  if (_0x19e7a2.executor.id == _0x46d551.guild.ownerId) {
    return
  }
  if (_0x561f93 <= 0) {
    return
  }
  if (_0x59e850 >= _0x561f93) {
    if (_0x3e58dc === 'rroles') {
      _0x46d551.guild.members.cache
        .get(_0x19e7a2.executor.id)
        .roles.cache.forEach((_0x2fda1a) => {
          _0x46d551.guild.members.cache
            .get(_0x19e7a2.executor.id)
            .roles.remove(_0x2fda1a.id)
            .catch((_0x18fcca) => {})
        })
    } else {
      if (_0x3e58dc === 'kick') {
        _0x46d551.guild.members.cache
          .get(_0x19e7a2.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x2ea33c) => {})
      } else {
        _0x3e58dc === 'ban' &&
          _0x46d551.guild.members.cache
            .get(_0x19e7a2.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x232bc8) => {})
      }
    }
    if (_0x3ae39f) {
      db.add(
        'userlimit_' +
          _0x46d551.guild.id +
          '_' +
          _0x19e7a2.executor.id +
          '.ban',
        1
      )
      let _0x6ed19e = _0x46d551.guild.channels.cache.get(_0x3ae39f),
        _0x258cfc = new Discord.MessageEmbed()
          .setTitle('Member Banned')
          .addFields(
            {
              name: 'تم حظر العضو',
              value: '<@' + _0x46d551.user.id + '>',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x19e7a2.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x59e850 +
                '/' +
                _0x561f93 +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x3e58dc === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x3e58dc === 'kick'
                  ? 'طرد العضو'
                  : _0x3e58dc === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0x6ed19e) {
        _0x6ed19e.send({ embeds: [_0x258cfc] })
      }
    }
  } else {
    db.add(
      'userlimit_' + _0x46d551.guild.id + '_' + _0x19e7a2.executor.id + '.ban',
      1
    )
    let _0x24400c = _0x46d551.guild.channels.cache.get(_0x3ae39f),
      _0x2b0fdb = new Discord.MessageEmbed()
        .setTitle('Member Banned')
        .addFields(
          {
            name: 'تم حظر العضو',
            value: '<@' + _0x46d551.user.id + '>',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x19e7a2.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x59e850 + '/' + _0x561f93,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x3e58dc === 'rroles'
                ? 'ازالة الرتب'
                : _0x3e58dc === 'kick'
                ? 'طرد العضو'
                : _0x3e58dc === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x24400c) {
      _0x24400c.send({ embeds: [_0x2b0fdb] })
    }
  }
})
client.on('guildMemberRemove', async (_0x1821e6, _0x487c38) => {
  let _0x457dcc = await _0x1821e6.guild.fetchAuditLogs({
      limit: 1,
      type: 'MEMBER_KICK',
    }),
    _0x59fed8 = _0x457dcc.entries.first(),
    _0x4e25c3 = db.get('limit_' + _0x1821e6.guild.id + '.kick'),
    _0x3960bb = db.get(
      'userlimit_' + _0x1821e6.guild.id + '_' + _0x59fed8.executor.id + '.kick'
    )
  !_0x3960bb &&
    (db.set(
      'userlimit_' + _0x1821e6.guild.id + '_' + _0x59fed8.executor.id + '.kick',
      1
    ),
    (_0x3960bb = 1))
  let _0x9dc088 = db.get('punishment_' + _0x1821e6.guild.id),
    _0x3636e9 = db.get('log_' + _0x1821e6.guild.id),
    _0xd72d5a = db.get('trusted_' + _0x1821e6.guild.id)
  if (!_0x4e25c3 || !_0x9dc088) {
    return
  }
  if (
    _0xd72d5a &&
    _0xd72d5a.find((_0x3753a3) => _0x3753a3.user == _0x59fed8.executor.id)
  ) {
    return
  }
  if (_0x59fed8.executor.id == client.user.id) {
    return
  }
  if (_0x59fed8.executor.id == _0x1821e6.guild.ownerId) {
    return
  }
  if (_0x4e25c3 <= 0) {
    return
  }
  if (_0x3960bb >= _0x4e25c3) {
    if (_0x9dc088 === 'rroles') {
      _0x1821e6.guild.members.cache
        .get(_0x59fed8.executor.id)
        .roles.cache.forEach((_0x4ef8ed) => {
          _0x1821e6.guild.members.cache
            .get(_0x59fed8.executor.id)
            .roles.remove(_0x4ef8ed.id)
            .catch((_0x2921e7) => {})
        })
    } else {
      if (_0x9dc088 === 'kick') {
        _0x1821e6.guild.members.cache
          .get(_0x59fed8.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x32684b) => {})
      } else {
        _0x9dc088 === 'ban' &&
          _0x1821e6.guild.members.cache
            .get(_0x59fed8.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x3de0f4) => {})
      }
    }
    if (_0x3636e9) {
      db.add(
        'userlimit_' +
          _0x1821e6.guild.id +
          '_' +
          _0x59fed8.executor.id +
          '.kick',
        1
      )
      let _0x4aaf51 = _0x1821e6.guild.channels.cache.get(_0x3636e9),
        _0x4c0b18 = new Discord.MessageEmbed()
          .setTitle('Member Kicked')
          .addFields(
            {
              name: 'تم طرد العضو',
              value: '<@' + _0x1821e6.user.id + '>',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x59fed8.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x3960bb +
                '/' +
                _0x4e25c3 +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x9dc088 === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x9dc088 === 'kick'
                  ? 'طرد العضو'
                  : _0x9dc088 === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0x4aaf51) {
        _0x4aaf51.send({ embeds: [_0x4c0b18] })
      }
    }
  } else {
    db.add(
      'userlimit_' + _0x1821e6.guild.id + '_' + _0x59fed8.executor.id + '.kick',
      1
    )
    let _0x23093f = _0x1821e6.guild.channels.cache.get(_0x3636e9),
      _0x1d90be = new Discord.MessageEmbed()
        .setTitle('Member Kicked')
        .addFields(
          {
            name: 'تم طرد العضو',
            value: '<@' + _0x1821e6.user.id + '>',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x59fed8.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x3960bb + '/' + _0x4e25c3,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x9dc088 === 'rroles'
                ? 'ازالة الرتب'
                : _0x9dc088 === 'kick'
                ? 'طرد العضو'
                : _0x9dc088 === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x23093f) {
      _0x23093f.send({ embeds: [_0x1d90be] })
    }
  }
})
client.on('guildBanRemove', async (_0x544b37, _0x5b7841) => {
  let _0x1dfd0d = await _0x544b37.guild.fetchAuditLogs({
      limit: 1,
      type: 'MEMBER_BAN_REMOVE',
    }),
    _0x22f720 = _0x1dfd0d.entries.first(),
    _0x54b1f2 = db.get('limit_' + _0x544b37.guild.id + '.ban'),
    _0x31a051 = db.get(
      'userlimit_' + _0x544b37.guild.id + '_' + _0x22f720.executor.id + '.ban'
    )
  !_0x31a051 &&
    (db.set(
      'userlimit_' + _0x544b37.guild.id + '_' + _0x22f720.executor.id + '.ban',
      1
    ),
    (_0x31a051 = 1))
  let _0xc02c9d = db.get('punishment_' + _0x544b37.guild.id),
    _0x2c8fd9 = db.get('log_' + _0x544b37.guild.id),
    _0x46d89e = db.get('trusted_' + _0x544b37.guild.id)
  if (!_0x54b1f2 || !_0xc02c9d) {
    return
  }
  if (
    _0x46d89e &&
    _0x46d89e.find((_0x5ac47a) => _0x5ac47a.user == _0x22f720.executor.id)
  ) {
    return
  }
  if (_0x22f720.executor.id == client.user.id) {
    return
  }
  if (_0x22f720.executor.id == _0x544b37.guild.ownerId) {
    return
  }
  if (_0x54b1f2 <= 0) {
    return
  }
  if (_0x31a051 >= _0x54b1f2) {
    if (_0xc02c9d === 'rroles') {
      _0x544b37.guild.members.cache
        .get(_0x22f720.executor.id)
        .roles.cache.forEach((_0x3393b1) => {
          _0x544b37.guild.members.cache
            .get(_0x22f720.executor.id)
            .roles.remove(_0x3393b1.id)
            .catch((_0x279a58) => {})
        })
    } else {
      if (_0xc02c9d === 'kick') {
        _0x544b37.guild.members.cache
          .get(_0x22f720.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x713e2) => {})
      } else {
        _0xc02c9d === 'ban' &&
          _0x544b37.guild.members.cache
            .get(_0x22f720.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x28cb54) => {})
      }
    }
    if (_0x2c8fd9) {
      db.add(
        'userlimit_' +
          _0x544b37.guild.id +
          '_' +
          _0x22f720.executor.id +
          '.ban',
        1
      )
      let _0x43e3a6 = _0x544b37.guild.channels.cache.get(_0x2c8fd9),
        _0x37915b = new Discord.MessageEmbed()
          .setTitle('Member Unbanned')
          .addFields(
            {
              name: 'تم فك الحظر عن العضو',
              value: '<@' + _0x544b37.user.id + '>',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x22f720.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x31a051 +
                '/' +
                _0x54b1f2 +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0xc02c9d === 'rroles'
                  ? 'ازالة الرتب'
                  : _0xc02c9d === 'kick'
                  ? 'طرد العضو'
                  : _0xc02c9d === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0x43e3a6) {
        _0x43e3a6.send({ embeds: [_0x37915b] })
      }
    }
  } else {
    db.add(
      'userlimit_' + _0x544b37.guild.id + '_' + _0x22f720.executor.id + '.ban',
      1
    )
    let _0x3221bd = _0x544b37.guild.channels.cache.get(_0x2c8fd9),
      _0xb075e0 = new Discord.MessageEmbed()
        .setTitle('Member Banned')
        .addFields(
          {
            name: 'تم فك الحظر عن العضو',
            value: '<@' + _0x544b37.user.id + '>',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x22f720.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x31a051 + '/' + _0x54b1f2,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0xc02c9d === 'rroles'
                ? 'ازالة الرتب'
                : _0xc02c9d === 'kick'
                ? 'طرد العضو'
                : _0xc02c9d === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x3221bd) {
      _0x3221bd.send({ embeds: [_0xb075e0] })
    }
  }
})
client.on('roleCreate', async (_0x473dbc, _0x433d75) => {
  let _0x4c01cd = await _0x473dbc.guild.fetchAuditLogs({
      limit: 1,
      type: 'ROLE_CREATE',
    }),
    _0x2970fe = _0x4c01cd.entries.first(),
    _0x2a4361 = db.get('limit_' + _0x473dbc.guild.id + '.crole'),
    _0x3206a6 = db.get(
      'userlimit_' + _0x473dbc.guild.id + '_' + _0x2970fe.executor.id + '.crole'
    )
  !_0x3206a6 &&
    (db.set(
      'userlimit_' +
        _0x473dbc.guild.id +
        '_' +
        _0x2970fe.executor.id +
        '.crole',
      1
    ),
    (_0x3206a6 = 1))
  if (_0x473dbc.managed) {
    return
  }
  let _0x575e57 = db.get('punishment_' + _0x473dbc.guild.id),
    _0x206695 = db.get('log_' + _0x473dbc.guild.id),
    _0x58a4ec = db.get('trusted_' + _0x473dbc.guild.id)
  if (!_0x2a4361 || !_0x575e57) {
    return
  }
  if (
    _0x58a4ec &&
    _0x58a4ec.find((_0x1a365c) => _0x1a365c.user == _0x2970fe.executor.id)
  ) {
    return
  }
  if (_0x2970fe.executor.id == client.user.id) {
    return
  }
  if (_0x2970fe.executor.id == _0x473dbc.guild.ownerId) {
    return
  }
  if (_0x2a4361 <= 0) {
    return
  }
  if (_0x3206a6 >= _0x2a4361) {
    if (_0x575e57 === 'rroles') {
      _0x473dbc.guild.members.cache
        .get(_0x2970fe.executor.id)
        .roles.cache.forEach((_0x23f8f7) => {
          _0x473dbc.guild.members.cache
            .get(_0x2970fe.executor.id)
            .roles.remove(_0x23f8f7.id)
            .catch((_0x8d7f02) => {})
        })
    } else {
      if (_0x575e57 === 'kick') {
        _0x473dbc.guild.members.cache
          .get(_0x2970fe.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x57fb1c) => {})
      } else {
        _0x575e57 === 'ban' &&
          _0x473dbc.guild.members.cache
            .get(_0x2970fe.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x348788) => {})
      }
    }
    if (_0x206695) {
      db.add(
        'userlimit_' +
          _0x473dbc.guild.id +
          '_' +
          _0x2970fe.executor.id +
          '.crole',
        1
      )
      let _0x3a43f3 = _0x473dbc.guild.channels.cache.get(_0x206695),
        _0x1952e2 = new Discord.MessageEmbed()
          .setTitle('Role Created')
          .addFields(
            {
              name: 'تم انشاء رتبة',
              value: '<@&' + _0x473dbc.id + '> (Name: ' + _0x473dbc.name + ')',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x2970fe.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x3206a6 +
                '/' +
                _0x2a4361 +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x575e57 === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x575e57 === 'kick'
                  ? 'طرد العضو'
                  : _0x575e57 === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0x3a43f3) {
        _0x3a43f3.send({ embeds: [_0x1952e2] })
      }
    }
  } else {
    db.add(
      'userlimit_' +
        _0x473dbc.guild.id +
        '_' +
        _0x2970fe.executor.id +
        '.crole',
      1
    )
    let _0x469ac9 = _0x473dbc.guild.channels.cache.get(_0x206695),
      _0x3874aa = new Discord.MessageEmbed()
        .setTitle('Role Created')
        .addFields(
          {
            name: 'تم انشاء رتبة',
            value: '<@&' + _0x473dbc.id + '> (Name: ' + _0x473dbc.name + ')',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x2970fe.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x3206a6 + '/' + _0x2a4361,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x575e57 === 'rroles'
                ? 'ازالة الرتب'
                : _0x575e57 === 'kick'
                ? 'طرد العضو'
                : _0x575e57 === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x469ac9) {
      _0x469ac9.send({ embeds: [_0x3874aa] })
    }
  }
})
client.on('roleDelete', async (_0x3ca6b5, _0x13384c) => {
  let _0x215187 = await _0x3ca6b5.guild.fetchAuditLogs({
      limit: 1,
      type: 'ROLE_DELETE',
    }),
    _0x4bd411 = _0x215187.entries.first(),
    _0x13c0e4 = db.get('limit_' + _0x3ca6b5.guild.id + '.drole'),
    _0x552c6f = db.get(
      'userlimit_' + _0x3ca6b5.guild.id + '_' + _0x4bd411.executor.id + '.drole'
    )
  !_0x552c6f &&
    (db.set(
      'userlimit_' +
        _0x3ca6b5.guild.id +
        '_' +
        _0x4bd411.executor.id +
        '.drole',
      1
    ),
    (_0x552c6f = 1))
  if (_0x3ca6b5.managed) {
    return
  }
  let _0x12d65f = db.get('punishment_' + _0x3ca6b5.guild.id),
    _0x3a6963 = db.get('log_' + _0x3ca6b5.guild.id),
    _0x5587e0 = db.get('trusted_' + _0x3ca6b5.guild.id)
  if (!_0x13c0e4 || !_0x12d65f) {
    return
  }
  if (
    _0x5587e0 &&
    _0x5587e0.find((_0x4bae72) => _0x4bae72.user == _0x4bd411.executor.id)
  ) {
    return
  }
  if (_0x4bd411.executor.id == client.user.id) {
    return
  }
  if (_0x4bd411.executor.id == _0x3ca6b5.guild.ownerId) {
    return
  }
  if (_0x13c0e4 <= 0) {
    return
  }
  if (_0x552c6f >= _0x13c0e4) {
    if (_0x12d65f === 'rroles') {
      _0x3ca6b5.guild.members.cache
        .get(_0x4bd411.executor.id)
        .roles.cache.forEach((_0x472109) => {
          _0x3ca6b5.guild.members.cache
            .get(_0x4bd411.executor.id)
            .roles.remove(_0x472109.id)
            .catch((_0xb2c94d) => {})
        })
    } else {
      if (_0x12d65f === 'kick') {
        _0x3ca6b5.guild.members.cache
          .get(_0x4bd411.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x4634f5) => {})
      } else {
        _0x12d65f === 'ban' &&
          _0x3ca6b5.guild.members.cache
            .get(_0x4bd411.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x335ca2) => {})
      }
    }
    if (_0x3a6963) {
      db.add(
        'userlimit_' +
          _0x3ca6b5.guild.id +
          '_' +
          _0x4bd411.executor.id +
          '.drole',
        1
      )
      let _0xdfd094 = _0x3ca6b5.guild.channels.cache.get(_0x3a6963),
        _0x5f4501 = new Discord.MessageEmbed()
          .setTitle('Role Deleted')
          .addFields(
            {
              name: 'تم حذف رتبة',
              value: '<@&' + _0x3ca6b5.id + '> (Name: ' + _0x3ca6b5.name + ')',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x4bd411.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x552c6f +
                '/' +
                _0x13c0e4 +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x12d65f === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x12d65f === 'kick'
                  ? 'طرد العضو'
                  : _0x12d65f === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0xdfd094) {
        _0xdfd094.send({ embeds: [_0x5f4501] })
      }
    }
  } else {
    db.add(
      'userlimit_' +
        _0x3ca6b5.guild.id +
        '_' +
        _0x4bd411.executor.id +
        '.drole',
      1
    )
    let _0x5e95cf = _0x3ca6b5.guild.channels.cache.get(_0x3a6963),
      _0x4c5f5f = new Discord.MessageEmbed()
        .setTitle('Role Created')
        .addFields(
          {
            name: 'تم حذف رتبة',
            value: '<@&' + _0x3ca6b5.id + '> (Name: ' + _0x3ca6b5.name + ')',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x4bd411.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x552c6f + '/' + _0x13c0e4,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x12d65f === 'rroles'
                ? 'ازالة الرتب'
                : _0x12d65f === 'kick'
                ? 'طرد العضو'
                : _0x12d65f === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x5e95cf) {
      _0x5e95cf.send({ embeds: [_0x4c5f5f] })
    }
  }
})
client.on('roleUpdate', async (_0x1d95b3, _0x1bbf82) => {
  if (_0x1d95b3.rawPosition !== _0x1bbf82.rawPosition) {
    return
  }
  let _0x16c5dc = await _0x1d95b3.guild.fetchAuditLogs({
      limit: 1,
      type: 'ROLE_UPDATE',
    }),
    _0x247be7 = _0x16c5dc.entries.first(),
    _0x1453cf = db.get('limit_' + _0x1d95b3.guild.id + '.rename'),
    _0x288835 = db.get(
      'userlimit_' +
        _0x1d95b3.guild.id +
        '_' +
        _0x247be7.executor.id +
        '.rename'
    )
  !_0x288835 &&
    (db.set(
      'userlimit_' +
        _0x1d95b3.guild.id +
        '_' +
        _0x247be7.executor.id +
        '.rename',
      1
    ),
    (_0x288835 = 1))
  var _0x5ab623
  if (_0x1bbf82.name !== _0x1d95b3.name) {
    _0x5ab623 = 'name'
  }
  if (_0x1bbf82.permissions.bitfield !== _0x1d95b3.permissions.bitfield) {
    _0x5ab623 = 'permissions'
  }
  if (!_0x5ab623) {
    return
  }
  let _0x1b8e2c = db.get('punishment_' + _0x1d95b3.guild.id),
    _0xec13ea = db.get('log_' + _0x1d95b3.guild.id),
    _0x27d6c2 = db.get('trusted_' + _0x1d95b3.guild.id)
  if (!_0x1453cf || !_0x1b8e2c) {
    return
  }
  if (
    _0x27d6c2 &&
    _0x27d6c2.find((_0xf26c8c) => _0xf26c8c.user == _0x247be7.executor.id)
  ) {
    return
  }
  if (_0x247be7.executor.id == client.user.id) {
    return
  }
  if (_0x247be7.executor.id == _0x1d95b3.guild.ownerId) {
    return
  }
  if (_0x1453cf <= 0) {
    return
  }
  if (_0x288835 >= _0x1453cf) {
    if (_0x1b8e2c === 'rroles') {
      _0x1d95b3.guild.members.cache
        .get(_0x247be7.executor.id)
        .roles.cache.forEach((_0xa3118f) => {
          _0x1d95b3.guild.members.cache
            .get(_0x247be7.executor.id)
            .roles.remove(_0xa3118f.id)
            .catch((_0x2b336d) => {})
        })
    } else {
      if (_0x1b8e2c === 'kick') {
        _0x1d95b3.guild.members.cache
          .get(_0x247be7.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x24b75a) => {})
      } else {
        _0x1b8e2c === 'ban' &&
          _0x1d95b3.guild.members.cache
            .get(_0x247be7.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x272145) => {})
      }
    }
    if (_0xec13ea) {
      db.add(
        'userlimit_' +
          _0x1d95b3.guild.id +
          '_' +
          _0x247be7.executor.id +
          '.rename',
        1
      )
      let _0xe08ebd = _0x1d95b3.guild.channels.cache.get(_0xec13ea),
        _0x3b87a1 = new Discord.MessageEmbed()
          .setTitle('Role Updated')
          .addFields(
            {
              name:
                'تم تعديل رتبة (' +
                (_0x5ab623 === 'name'
                  ? 'الاسم'
                  : _0x5ab623 === 'permissions'
                  ? 'الصلاحيات'
                  : 'غير محدد') +
                ')',
              value: '<@&' + _0x1d95b3.id + '> (Name: ' + _0x1bbf82.name + ')',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x247be7.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x288835 +
                '/' +
                _0x1453cf +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x1b8e2c === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x1b8e2c === 'kick'
                  ? 'طرد العضو'
                  : _0x1b8e2c === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0xe08ebd) {
        _0xe08ebd.send({ embeds: [_0x3b87a1] })
      }
    }
  } else {
    db.add(
      'userlimit_' +
        _0x1d95b3.guild.id +
        '_' +
        _0x247be7.executor.id +
        '.rename',
      1
    )
    let _0x2aea31 = _0x1d95b3.guild.channels.cache.get(_0xec13ea),
      _0x18130a = new Discord.MessageEmbed()
        .setTitle('Role Updated')
        .addFields(
          {
            name:
              'تم تعديل رتبة (' +
              (_0x5ab623 === 'name'
                ? 'الاسم'
                : _0x5ab623 === 'permissions'
                ? 'الصلاحيات'
                : 'غير محدد') +
              ')',
            value: '<@&' + _0x1d95b3.id + '> (Name: ' + _0x1bbf82.name + ')',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x247be7.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x288835 + '/' + _0x1453cf,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x1b8e2c === 'rroles'
                ? 'ازالة الرتب'
                : _0x1b8e2c === 'kick'
                ? 'طرد العضو'
                : _0x1b8e2c === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x2aea31) {
      _0x2aea31.send({ embeds: [_0x18130a] })
    }
  }
})
client.on('channelCreate', async (_0x137306, _0x7403c6) => {
  let _0x5a50a6 = await _0x137306.guild.fetchAuditLogs({
      limit: 1,
      type: 'CHANNEL_CREATE',
    }),
    _0x148cdf = _0x5a50a6.entries.first(),
    _0x32975b = db.get('limit_' + _0x137306.guild.id + '.cchannel'),
    _0xcd4198 = db.get(
      'userlimit_' +
        _0x137306.guild.id +
        '_' +
        _0x148cdf.executor.id +
        '.cchannel'
    )
  !_0xcd4198 &&
    (db.set(
      'userlimit_' +
        _0x137306.guild.id +
        '_' +
        _0x148cdf.executor.id +
        '.cchannel',
      1
    ),
    (_0xcd4198 = 1))
  let _0x376b58 = db.get('punishment_' + _0x137306.guild.id),
    _0x486045 = db.get('log_' + _0x137306.guild.id),
    _0x43380c = db.get('trusted_' + _0x137306.guild.id)
  if (!_0x32975b || !_0x376b58) {
    return
  }
  if (
    _0x43380c &&
    _0x43380c.find((_0x22060b) => _0x22060b.user == _0x148cdf.executor.id)
  ) {
    return
  }
  if (_0x148cdf.executor.id == client.user.id) {
    return
  }
  if (_0x148cdf.executor.id == _0x137306.guild.ownerId) {
    return
  }
  if (_0x32975b <= 0) {
    return
  }
  if (_0xcd4198 >= _0x32975b) {
    if (_0x376b58 === 'rroles') {
      _0x137306.guild.members.cache
        .get(_0x148cdf.executor.id)
        .roles.cache.forEach((_0x51e5ce) => {
          _0x137306.guild.members.cache
            .get(_0x148cdf.executor.id)
            .roles.remove(_0x51e5ce.id)
            .catch((_0x4590ea) => {})
        })
    } else {
      if (_0x376b58 === 'kick') {
        _0x137306.guild.members.cache
          .get(_0x148cdf.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x286ffa) => {})
      } else {
        _0x376b58 === 'ban' &&
          _0x137306.guild.members.cache
            .get(_0x148cdf.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x82ca6c) => {})
      }
    }
    if (_0x486045) {
      db.add(
        'userlimit_' +
          _0x137306.guild.id +
          '_' +
          _0x148cdf.executor.id +
          '.cchannel',
        1
      )
      let _0x260c3d = _0x137306.guild.channels.cache.get(_0x486045),
        _0x5483fb = new Discord.MessageEmbed()
          .setTitle('Channel Created')
          .addFields(
            {
              name: 'تم انشاء روم',
              value: '<#' + _0x137306.id + '> (Name: ' + _0x137306.name + ')',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x148cdf.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0xcd4198 +
                '/' +
                _0x32975b +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x376b58 === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x376b58 === 'kick'
                  ? 'طرد العضو'
                  : _0x376b58 === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0x260c3d) {
        _0x260c3d.send({ embeds: [_0x5483fb] })
      }
    }
  } else {
    db.add(
      'userlimit_' +
        _0x137306.guild.id +
        '_' +
        _0x148cdf.executor.id +
        '.cchannel',
      1
    )
    let _0x17b037 = _0x137306.guild.channels.cache.get(_0x486045),
      _0x13cbfc = new Discord.MessageEmbed()
        .setTitle('Channel Created')
        .addFields(
          {
            name: 'تم انشاء روم',
            value: '<#' + _0x137306.id + '> (Name: ' + _0x137306.name + ')',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x148cdf.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0xcd4198 + '/' + _0x32975b,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x376b58 === 'rroles'
                ? 'ازالة الرتب'
                : _0x376b58 === 'kick'
                ? 'طرد العضو'
                : _0x376b58 === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x17b037) {
      _0x17b037.send({ embeds: [_0x13cbfc] })
    }
  }
})
client.on('channelDelete', async (_0x226c97, _0x42fac0) => {
  let _0x3e6078 = await _0x226c97.guild.fetchAuditLogs({
      limit: 1,
      type: 'CHANNEL_DELETE',
    }),
    _0x1cb6d2 = _0x3e6078.entries.first(),
    _0x361cf7 = db.get('limit_' + _0x226c97.guild.id + '.dchannel'),
    _0xf48e1d = db.get(
      'userlimit_' +
        _0x226c97.guild.id +
        '_' +
        _0x1cb6d2.executor.id +
        '.dchannel'
    )
  !_0xf48e1d &&
    (db.set(
      'userlimit_' +
        _0x226c97.guild.id +
        '_' +
        _0x1cb6d2.executor.id +
        '.dchannel',
      1
    ),
    (_0xf48e1d = 1))
  let _0x2dc277 = db.get('punishment_' + _0x226c97.guild.id),
    _0x3a19fe = db.get('log_' + _0x226c97.guild.id),
    _0x311b91 = db.get('trusted_' + _0x226c97.guild.id)
  if (!_0x361cf7 || !_0x2dc277) {
    return
  }
  if (
    _0x311b91 &&
    _0x311b91.find((_0x5a380a) => _0x5a380a.user == _0x1cb6d2.executor.id)
  ) {
    return
  }
  if (_0x1cb6d2.executor.id == client.user.id) {
    return
  }
  if (_0x1cb6d2.executor.id == _0x226c97.guild.ownerId) {
    return
  }
  if (_0x361cf7 <= 0) {
    return
  }
  if (_0xf48e1d >= _0x361cf7) {
    if (_0x2dc277 === 'rroles') {
      _0x226c97.guild.members.cache
        .get(_0x1cb6d2.executor.id)
        .roles.cache.forEach((_0x1538fc) => {
          _0x226c97.guild.members.cache
            .get(_0x1cb6d2.executor.id)
            .roles.remove(_0x1538fc.id)
            .catch((_0x5492cd) => {})
        })
    } else {
      if (_0x2dc277 === 'kick') {
        _0x226c97.guild.members.cache
          .get(_0x1cb6d2.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x33586e) => {})
      } else {
        _0x2dc277 === 'ban' &&
          _0x226c97.guild.members.cache
            .get(_0x1cb6d2.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x2ac642) => {})
      }
    }
    if (_0x3a19fe) {
      db.add(
        'userlimit_' +
          _0x226c97.guild.id +
          '_' +
          _0x1cb6d2.executor.id +
          '.dchannel',
        1
      )
      let _0xda566b = _0x226c97.guild.channels.cache.get(_0x3a19fe),
        _0xc91027 = new Discord.MessageEmbed()
          .setTitle('Channel Deleted')
          .addFields(
            {
              name: 'تم حذف روم',
              value: '<#' + _0x226c97.id + '> (Name: ' + _0x226c97.name + ')',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x1cb6d2.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0xf48e1d +
                '/' +
                _0x361cf7 +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x2dc277 === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x2dc277 === 'kick'
                  ? 'طرد العضو'
                  : _0x2dc277 === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0xda566b) {
        _0xda566b.send({ embeds: [_0xc91027] })
      }
    }
  } else {
    db.add(
      'userlimit_' +
        _0x226c97.guild.id +
        '_' +
        _0x1cb6d2.executor.id +
        '.dchannel',
      1
    )
    let _0x5f360a = _0x226c97.guild.channels.cache.get(_0x3a19fe),
      _0x77c7cb = new Discord.MessageEmbed()
        .setTitle('Channel Deleted')
        .addFields(
          {
            name: 'تم حذف روم',
            value: '<#' + _0x226c97.id + '> (Name: ' + _0x226c97.name + ')',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x1cb6d2.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0xf48e1d + '/' + _0x361cf7,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x2dc277 === 'rroles'
                ? 'ازالة الرتب'
                : _0x2dc277 === 'kick'
                ? 'طرد العضو'
                : _0x2dc277 === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x5f360a) {
      _0x5f360a.send({ embeds: [_0x77c7cb] })
    }
  }
})
client.on('channelUpdate', async (_0x52a5e4, _0xd3646f) => {
  if (
    _0x52a5e4.permissionOverwrites === _0xd3646f.permissionOverwrites &&
    _0x52a5e4.name === _0xd3646f.name
  ) {
    return
  }
  if (_0x52a5e4.rawPosition !== _0xd3646f.rawPosition) {
    return
  }
  let _0x18c33f = await _0x52a5e4.guild.fetchAuditLogs({
      limit: 1,
      type: 'CHANNEL_UPDATE',
    }),
    _0x35836e = _0x18c33f.entries.first(),
    _0x202233 = db.get('limit_' + _0x52a5e4.guild.id + '.rename'),
    _0x2c2992 = db.get(
      'userlimit_' +
        _0x52a5e4.guild.id +
        '_' +
        _0x35836e.executor.id +
        '.rename'
    )
  !_0x2c2992 &&
    (db.set(
      'userlimit_' +
        _0x52a5e4.guild.id +
        '_' +
        _0x35836e.executor.id +
        '.rename',
      1
    ),
    (_0x2c2992 = 1))
  let _0x35c5d5 = db.get('punishment_' + _0x52a5e4.guild.id)
  var _0x4d3f74
  if (_0xd3646f.name !== _0x52a5e4.name) {
    _0x4d3f74 = 'name'
  }
  if (_0xd3646f.permissionOverwrites !== _0x52a5e4.permissionOverwrites) {
    _0x4d3f74 = 'permissions'
  }
  let _0x44518a = db.get('log_' + _0x52a5e4.guild.id),
    _0x36980b = db.get('trusted_' + _0x52a5e4.guild.id)
  if (!_0x202233 || !_0x35c5d5) {
    return
  }
  if (
    _0x36980b &&
    _0x36980b.find((_0x15c54f) => _0x15c54f.user == _0x35836e.executor.id)
  ) {
    return
  }
  if (_0x35836e.executor.id == client.user.id) {
    return
  }
  if (_0x35836e.executor.id == _0x52a5e4.guild.ownerId) {
    return
  }
  if (_0x202233 <= 0) {
    return
  }
  if (_0x2c2992 >= _0x202233) {
    if (_0x35c5d5 === 'rroles') {
      _0x52a5e4.guild.members.cache
        .get(_0x35836e.executor.id)
        .roles.cache.forEach((_0x58c7e5) => {
          _0x52a5e4.guild.members.cache
            .get(_0x35836e.executor.id)
            .roles.remove(_0x58c7e5.id)
            .catch((_0x4b55ad) => {})
        })
    } else {
      if (_0x35c5d5 === 'kick') {
        _0x52a5e4.guild.members.cache
          .get(_0x35836e.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x23ab4d) => {})
      } else {
        _0x35c5d5 === 'ban' &&
          _0x52a5e4.guild.members.cache
            .get(_0x35836e.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x2a2a47) => {})
      }
    }
    if (_0x44518a) {
      db.add(
        'userlimit_' +
          _0x52a5e4.guild.id +
          '_' +
          _0x35836e.executor.id +
          '.rename',
        1
      )
      let _0xb7af81 = _0x52a5e4.guild.channels.cache.get(_0x44518a),
        _0x241153 = new Discord.MessageEmbed()
          .setTitle('Channel Updated')
          .addFields(
            {
              name:
                'تم تعديل روم (' +
                (_0x4d3f74 === 'name'
                  ? 'الاسم'
                  : _0x4d3f74 === 'permissions'
                  ? 'الصلاحيات'
                  : 'غير محدد') +
                ')',
              value: '<#' + _0x52a5e4.id + '> (Name: ' + _0xd3646f.name + ')',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x35836e.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x2c2992 +
                '/' +
                _0x202233 +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x35c5d5 === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x35c5d5 === 'kick'
                  ? 'طرد العضو'
                  : _0x35c5d5 === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0xb7af81) {
        _0xb7af81.send({ embeds: [_0x241153] })
      }
    }
  } else {
    db.add(
      'userlimit_' +
        _0x52a5e4.guild.id +
        '_' +
        _0x35836e.executor.id +
        '.rename',
      1
    )
    let _0x36a13f = _0x52a5e4.guild.channels.cache.get(_0x44518a),
      _0x3ddd9f = new Discord.MessageEmbed()
        .setTitle('Channel Updated')
        .addFields(
          {
            name:
              'تم تعديل روم (' +
              (_0x4d3f74 === 'name'
                ? 'الاسم'
                : _0x4d3f74 === 'permissions'
                ? 'الصلاحيات'
                : 'غير محدد') +
              ')',
            value: '<#' + _0x52a5e4.id + '> (Name: ' + _0xd3646f.name + ')',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x35836e.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x2c2992 + '/' + _0x202233,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x35c5d5 === 'rroles'
                ? 'ازالة الرتب'
                : _0x35c5d5 === 'kick'
                ? 'طرد العضو'
                : _0x35c5d5 === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x36a13f) {
      _0x36a13f.send({ embeds: [_0x3ddd9f] })
    }
  }
})
client.on('guildMemberUpdate', async (_0x454d12, _0x2eba34) => {
  if (_0x454d12.roles.cache === _0x2eba34.roles.cache) {
    return
  }
  var _0x50beb2, _0x372534
  _0x2eba34.roles.cache.forEach((_0x30c382) => {
    !_0x454d12.roles.cache.get(_0x30c382.id) &&
      ((_0x50beb2 = _0x30c382), (_0x372534 = 'add'))
  })
  _0x454d12.roles.cache.forEach((_0x1065d2) => {
    !_0x2eba34.roles.cache.get(_0x1065d2.id) &&
      ((_0x50beb2 = _0x1065d2), (_0x372534 = 'remove'))
  })
  if (_0x454d12.guild.roles.cache.get(_0x50beb2.id).managed) {
    return
  }
  if (_0x454d12.roles.cache === _0x2eba34.roles.cache) {
    return
  }
  let _0x2ed4c5 = await _0x454d12.guild.fetchAuditLogs({
      limit: 1,
      type: 'MEMBER_ROLE_UPDATE',
    }),
    _0x25ce1d = _0x2ed4c5.entries.first(),
    _0x547709 = db.get(
      'limit_' +
        _0x454d12.guild.id +
        '.' +
        (_0x372534 === 'add' ? 'arole' : 'rrole')
    ),
    _0x30c1a4 = db.get(
      'userlimit_' +
        _0x454d12.guild.id +
        '_' +
        _0x25ce1d.executor.id +
        '.' +
        (_0x372534 === 'add' ? 'arole' : 'rrole')
    )
  !_0x30c1a4 &&
    (db.set(
      'userlimit_' +
        _0x454d12.guild.id +
        '_' +
        _0x25ce1d.executor.id +
        '.' +
        (_0x372534 === 'add' ? 'arole' : 'rrole'),
      1
    ),
    (_0x30c1a4 = 1))
  let _0x14fa23 = db.get('punishment_' + _0x454d12.guild.id),
    _0x3f0eac = db.get('log_' + _0x454d12.guild.id),
    _0x5a11e0 = db.get('trusted_' + _0x454d12.guild.id)
  if (!_0x547709 || !_0x14fa23) {
    return
  }
  if (
    _0x5a11e0 &&
    _0x5a11e0.find((_0x2ab509) => _0x2ab509.user == _0x25ce1d.executor.id)
  ) {
    return
  }
  if (_0x25ce1d.executor.id == client.user.id) {
    return
  }
  if (_0x25ce1d.executor.id == _0x454d12.guild.ownerId) {
    return
  }
  if (_0x547709 <= 0) {
    return
  }
  if (_0x30c1a4 >= _0x547709) {
    if (_0x14fa23 === 'rroles') {
      _0x454d12.guild.members.cache
        .get(_0x25ce1d.executor.id)
        .roles.cache.forEach((_0x176848) => {
          _0x454d12.guild.members.cache
            .get(_0x25ce1d.executor.id)
            .roles.remove(_0x176848.id)
            .catch((_0x4d89ca) => {})
        })
    } else {
      if (_0x14fa23 === 'kick') {
        _0x454d12.guild.members.cache
          .get(_0x25ce1d.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x5bdc15) => {})
      } else {
        _0x14fa23 === 'ban' &&
          _0x454d12.guild.members.cache
            .get(_0x25ce1d.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0xafd3df) => {})
      }
    }
    if (_0x3f0eac) {
      db.add(
        'userlimit_' +
          _0x454d12.guild.id +
          '_' +
          _0x25ce1d.executor.id +
          '.' +
          (_0x372534 === 'add' ? 'arole' : 'rrole'),
        1
      )
      let _0x38fda8 = _0x454d12.guild.channels.cache.get(_0x3f0eac),
        _0x5279fa = new Discord.MessageEmbed()
          .setTitle('Role ' + (_0x372534 === 'add' ? 'Added' : 'Removed'))
          .addFields(
            {
              name: 'تم ' + (_0x372534 === 'add' ? 'اعطاء' : 'ازالة') + ' رتبة',
              value:
                '<@&' +
                _0x50beb2.id +
                '> (Name: ' +
                _0x454d12.guild.roles.cache.get(_0x50beb2.id).name +
                ')',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x25ce1d.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x30c1a4 +
                '/' +
                _0x547709 +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x14fa23 === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x14fa23 === 'kick'
                  ? 'طرد العضو'
                  : _0x14fa23 === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0x38fda8) {
        _0x38fda8.send({ embeds: [_0x5279fa] })
      }
    }
  } else {
    db.add(
      'userlimit_' +
        _0x454d12.guild.id +
        '_' +
        _0x25ce1d.executor.id +
        '.' +
        (_0x372534 === 'add' ? 'arole' : 'rrole'),
      1
    )
    let _0x358c95 = _0x454d12.guild.channels.cache.get(_0x3f0eac),
      _0x46225c = new Discord.MessageEmbed()
        .setTitle('Role ' + (_0x372534 === 'add' ? 'Added' : 'Removed'))
        .addFields(
          {
            name: 'تم ' + (_0x372534 === 'add' ? 'اعطاء' : 'ازالة') + ' رتبة',
            value:
              '<@&' +
              _0x50beb2.id +
              '> (Name: ' +
              _0x454d12.guild.roles.cache.get(_0x50beb2.id).name +
              ')',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x25ce1d.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x30c1a4 + '/' + _0x547709,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x14fa23 === 'rroles'
                ? 'ازالة الرتب'
                : _0x14fa23 === 'kick'
                ? 'طرد العضو'
                : _0x14fa23 === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x358c95) {
      _0x358c95.send({ embeds: [_0x46225c] })
    }
  }
})
client.on('guildUpdate', async (_0x5e9fc5, _0x3ef3b3) => {
  if (_0x5e9fc5.name === _0x3ef3b3.name && _0x5e9fc5.icon === _0x3ef3b3.icon) {
    return
  }
  var _0x3d28cd
  if (_0x5e9fc5.name !== _0x3ef3b3.name) {
    _0x3d28cd = 'name'
  }
  if (_0x5e9fc5.icon !== _0x3ef3b3.icon) {
    _0x3d28cd = 'icon'
  }
  let _0x28fa36 = await _0x5e9fc5.fetchAuditLogs({
      limit: 1,
      type: 'GUILD_UPDATE',
    }),
    _0x967d43 = _0x28fa36.entries.first(),
    _0x2b6055 = db.get('limit_' + _0x5e9fc5.id + '.rename'),
    _0x26a1b8 = db.get(
      'userlimit_' + _0x5e9fc5.id + '_' + _0x967d43.executor.id + '.rename'
    )
  !_0x26a1b8 &&
    (db.set(
      'userlimit_' + _0x5e9fc5.id + '_' + _0x967d43.executor.id + '.rename',
      1
    ),
    (_0x26a1b8 = 1))
  let _0x23c3cb = db.get('punishment_' + _0x5e9fc5.id),
    _0x79a6d = db.get('log_' + _0x5e9fc5.id),
    _0x4e2d95 = db.get('trusted_' + _0x5e9fc5.id)
  if (!_0x2b6055 || !_0x23c3cb) {
    return
  }
  if (
    _0x4e2d95 &&
    _0x4e2d95.find((_0x54b720) => _0x54b720.user == _0x967d43.executor.id)
  ) {
    return
  }
  if (_0x967d43.executor.id == client.user.id) {
    return
  }
  if (_0x967d43.executor.id == _0x5e9fc5.ownerId) {
    return
  }
  if (_0x2b6055 <= 0) {
    return
  }
  if (_0x26a1b8 >= _0x2b6055) {
    if (_0x23c3cb === 'rroles') {
      _0x5e9fc5.members.cache
        .get(_0x967d43.executor.id)
        .roles.cache.forEach((_0x37f668) => {
          _0x5e9fc5.members.cache
            .get(_0x967d43.executor.id)
            .roles.remove(_0x37f668.id)
            .catch((_0x48559b) => {})
        })
    } else {
      if (_0x23c3cb === 'kick') {
        _0x5e9fc5.members.cache
          .get(_0x967d43.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x206ee5) => {})
      } else {
        _0x23c3cb === 'ban' &&
          _0x5e9fc5.members.cache
            .get(_0x967d43.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0xf1f7d4) => {})
      }
    }
    if (_0x79a6d) {
      db.add(
        'userlimit_' + _0x5e9fc5.id + '_' + _0x967d43.executor.id + '.rename',
        1
      )
      let _0xb2d3c6 = _0x5e9fc5.channels.cache.get(_0x79a6d),
        _0x3e4110 = new Discord.MessageEmbed()
          .setTitle('Server Updated')
          .addFields(
            {
              name: 'تم تعديل السيرفر',
              value:
                'Name: ' +
                (_0x3d28cd === 'name'
                  ? _0x5e9fc5.name + ' => ' + _0x3ef3b3.name
                  : _0x3d28cd === 'icon'
                  ? 'Icon'
                  : 'غير محدد'),
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x967d43.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x26a1b8 +
                '/' +
                _0x2b6055 +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x23c3cb === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x23c3cb === 'kick'
                  ? 'طرد العضو'
                  : _0x23c3cb === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0xb2d3c6) {
        _0xb2d3c6.send({ embeds: [_0x3e4110] })
      }
    }
  } else {
    db.add(
      'userlimit_' + _0x5e9fc5.id + '_' + _0x967d43.executor.id + '.rename',
      1
    )
    let _0x199831 = _0x5e9fc5.channels.cache.get(_0x79a6d),
      _0x3156f1 = new Discord.MessageEmbed()
        .setTitle('Server Updated')
        .addFields(
          {
            name: 'تم تعديل السيرفر',
            value:
              'Name: ' +
              (_0x3d28cd === 'name'
                ? _0x5e9fc5.name + ' => ' + _0x3ef3b3.name
                : _0x3d28cd === 'icon'
                ? 'Icon'
                : 'غير محدد'),
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x967d43.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x26a1b8 + '/' + _0x2b6055,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x23c3cb === 'rroles'
                ? 'ازالة الرتب'
                : _0x23c3cb === 'kick'
                ? 'طرد العضو'
                : _0x23c3cb === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x199831) {
      _0x199831.send({ embeds: [_0x3156f1] })
    }
  }
})
client.on('guildMemberAdd', async (_0x7df0e4, _0x2091b8) => {
  let _0x338bd0 = await _0x7df0e4.guild.fetchAuditLogs({
      limit: 1,
      type: 'BOT_ADD',
    }),
    _0x33731b = _0x338bd0.entries.first(),
    _0x12265a = db.get('limit_' + _0x7df0e4.guild.id + '.antibots'),
    _0x207749 = db.get(
      'userlimit_' +
        _0x7df0e4.guild.id +
        '_' +
        _0x33731b.executor.id +
        '.antibots'
    ),
    _0x2c11ab = db.get('antibots_' + _0x7df0e4.guild.id)
  if (_0x2c11ab === 'disable') {
    return
  }
  !_0x207749 &&
    (db.set(
      'userlimit_' +
        _0x7df0e4.guild.id +
        '_' +
        _0x33731b.executor.id +
        '.antibots',
      1
    ),
    (_0x207749 = 1))
  let _0x2f2ad9 = db.get('punishment_' + _0x7df0e4.guild.id),
    _0x3e6962 = db.get('log_' + _0x7df0e4.guild.id),
    _0x59370c = db.get('trusted_' + _0x7df0e4.guild.id)
  if (!_0x12265a || !_0x2f2ad9) {
    return
  }
  if (!_0x2c11ab || _0x2c11ab === 'disable') {
    return
  }
  if (
    _0x59370c &&
    _0x59370c.find((_0x8194e6) => _0x8194e6.user == _0x33731b.executor.id)
  ) {
    return
  }
  if (_0x33731b.executor.id == client.user.id) {
    return
  }
  if (_0x33731b.executor.id == _0x7df0e4.guild.ownerId) {
    return
  }
  if (
    _0x2c11ab === 'enable-verified' &&
    _0x7df0e4.user.flags.bitfield === 65536
  ) {
    return
  }
  if (_0x12265a <= 0) {
    return
  }
  if (_0x207749 >= _0x12265a) {
    if (_0x2f2ad9 === 'rroles') {
      _0x7df0e4.guild.members.cache
        .get(_0x33731b.executor.id)
        .roles.cache.forEach((_0x3ee809) => {
          _0x7df0e4.guild.members.cache
            .get(_0x33731b.executor.id)
            .roles.remove(_0x3ee809.id)
            .catch((_0x4b7a16) => {})
        })
    } else {
      if (_0x2f2ad9 === 'kick') {
        _0x7df0e4.guild.members.cache
          .get(_0x33731b.executor.id)
          .kick({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
          .catch((_0x11efc2) => {})
      } else {
        _0x2f2ad9 === 'ban' &&
          _0x7df0e4.guild.members.cache
            .get(_0x33731b.executor.id)
            .ban({ reason: 'تجاوز الحد الاقصى للحماية سوهان' })
            .catch((_0x203602) => {})
      }
    }
    if (_0x3e6962) {
      db.add(
        'userlimit_' +
          _0x7df0e4.guild.id +
          '_' +
          _0x33731b.executor.id +
          '.antibots',
        1
      )
      _0x7df0e4.guild.members.cache
        .get(_0x7df0e4.id)
        .kick({ reason: 'Anti Bots' })
        .catch((_0x1f65a0) => {})
      let _0x291c6e = _0x7df0e4.guild.channels.cache.get(_0x3e6962),
        _0x594d96 = new Discord.MessageEmbed()
          .setTitle('Bot Added')
          .addFields(
            {
              name: 'تم اضافة بوت',
              value:
                '<@' +
                _0x7df0e4.id +
                '> (Name: ' +
                _0x7df0e4.user.username +
                ')',
            },
            {
              name: 'بواسطة',
              value: '<@' + _0x33731b.executor.id + '>',
            },
            {
              name: 'حد الحماية',
              value:
                'تجاوز الحد الاقصى للحماية سوهان (' +
                _0x207749 +
                '/' +
                _0x12265a +
                ')',
            },
            {
              name: 'العقوبة',
              value:
                '' +
                (_0x2f2ad9 === 'rroles'
                  ? 'ازالة الرتب'
                  : _0x2f2ad9 === 'kick'
                  ? 'طرد العضو'
                  : _0x2f2ad9 === 'ban'
                  ? 'حظر العضو'
                  : 'غير محدد'),
            }
          )
          .setTimestamp()
      if (_0x291c6e) {
        _0x291c6e.send({ embeds: [_0x594d96] })
      }
    }
  } else {
    db.add(
      'userlimit_' +
        _0x7df0e4.guild.id +
        '_' +
        _0x33731b.executor.id +
        '.antibots',
      1
    )
    _0x7df0e4.guild.members.cache
      .get(_0x7df0e4.id)
      .kick({ reason: 'Anti Bots' })
      .catch((_0x584897) => {})
    let _0x2cb313 = _0x7df0e4.guild.channels.cache.get(_0x3e6962),
      _0x37c265 = new Discord.MessageEmbed()
        .setTitle('Bot Added')
        .addFields(
          {
            name: 'تم اضافة بوت',
            value:
              '<@' + _0x7df0e4.id + '> (Name: ' + _0x7df0e4.user.username + ')',
          },
          {
            name: 'بواسطة',
            value: '<@' + _0x33731b.executor.id + '>',
          },
          {
            name: 'حد الحماية',
            value: _0x207749 + '/' + _0x12265a,
          },
          {
            name: 'العقوبة',
            value:
              '' +
              (_0x2f2ad9 === 'rroles'
                ? 'ازالة الرتب'
                : _0x2f2ad9 === 'kick'
                ? 'طرد العضو'
                : _0x2f2ad9 === 'ban'
                ? 'حظر العضو'
                : 'غير محدد'),
          }
        )
        .setTimestamp()
    if (_0x2cb313) {
      _0x2cb313.send({ embeds: [_0x37c265] })
    }
  }
})
process.on('unhandledRejection', (_0xb5a1aa) => {
  console.error('Unhandled Rejection: ' + _0xb5a1aa.stack)
})
process.on('uncaughtException', (_0x1ce181) => {
  console.error('Uncaught Exception: ' + _0x1ce181.stack)
})
module.exports = client
require('./Structures/Event')(client)
require('./Structures/slashCommand')(client)
client.start(client.config.token)